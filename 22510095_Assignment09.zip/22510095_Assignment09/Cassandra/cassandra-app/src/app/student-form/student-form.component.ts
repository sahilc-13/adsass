import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-student-form',
  standalone: true,
  imports: [ReactiveFormsModule, CommonModule],
  templateUrl: './student-form.component.html',
  styleUrl: './student-form.component.css'
})
export class StudentFormComponent implements OnInit {
  studentForm!: FormGroup;
  students: any[] = [];
  editingId: string | null = null;

  constructor(private fb: FormBuilder, private http: HttpClient) {}

  ngOnInit(): void {
    this.studentForm = this.fb.group({
      name: [''],
      prn: [''],
      email: [''],
      year: [''],
      branch: [''],
      college: ['']
    });

    this.getStudents();
  }

  getStudents() {
    this.http.get<any[]>('http://localhost:5001/api/students')
      .subscribe(data => this.students = data);
  }

  addOrUpdateStudent() {
    if (this.editingId) {
      this.http.put(`http://localhost:5001/api/students/${this.editingId}`, this.studentForm.value)
        .subscribe(() => {
          this.resetForm();
          this.getStudents();
        });
    } else {
      this.http.post('http://localhost:5001/api/students', this.studentForm.value)
        .subscribe(() => {
          this.studentForm.reset();
          this.getStudents();
        });
    }
  }

  editStudent(student: any) {
    this.studentForm.setValue({
      name: student.name,
      prn: student.prn,
      email: student.email,
      year: student.year,
      branch: student.branch,
      college: student.college
    });
    this.editingId = student.id; // ✅ FIXED: was _id before
  }

  deleteStudent(id: string) {
    this.http.delete(`http://localhost:5001/api/students/${id}`)
      .subscribe(() => this.getStudents());
  }

  resetForm() {
    this.studentForm.reset();
    this.editingId = null;
  }
}
