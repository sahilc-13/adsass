const express = require("express");
const cors = require("cors");
const { v4: uuidv4 } = require("uuid");
const cassandra = require("cassandra-driver");

const app = express();
app.use(cors());
app.use(express.json());
const Uuid = cassandra.types.Uuid;

// Cassandra authentication
const authProvider = new cassandra.auth.PlainTextAuthProvider(
  "HiZvllIvQuIWdlabcENoTHtw",
  "1mD5t.rIZnmT77PjPvQ+7sGHAJusdZj0FGH-57wU9xipmmgMfzX.85-+fJxPUfR,z.l5cYZqvNf,ElXOkCcHiDrDJzvezY_7q8K.r5Mj,rW2s8TpcY5q.k6+Y8kWrnZm"
);

// Cassandra client setup
const client = new cassandra.Client({
  cloud: { secureConnectBundle: "./secure-connect-abc.zip" },
  keyspace: "22510095", // Make sure this exists in your DB
  authProvider,
});

// Connect to DB
client
  .connect()
  .then(() => console.log("✅ Connected to Astra DB"))
  .catch((err) =>
    console.error("❌ Error connecting to Astra DB:", err.message)
  );

// GET all students
app.get("/api/students", async (req, res) => {
  try {
    console.log("📥 Fetching all students...");
    const result = await client.execute("SELECT * FROM students");
    res.json(result.rows);
  } catch (err) {
    console.error("❌ GET /api/students error:", err.message);
    res
      .status(500)
      .json({ error: "Failed to retrieve students", details: err.message });
  }
});

// POST new student
app.post("/api/students", async (req, res) => {
  const id = uuidv4();
  const { name, prn, email, year, branch, college } = req.body;
  try {
    await client.execute(
      "INSERT INTO students (id, name, prn, email, year, branch, college) VALUES (?, ?, ?, ?, ?, ?, ?)",
      [id, name, prn, email, parseInt(year), branch, college],
      { prepare: true }
    );
    console.log("✅ Inserted student:", name);
    res.json({ message: "Inserted" });
  } catch (err) {
    console.error("❌ POST /api/students error:", err.message);
    res
      .status(500)
      .json({ error: "Failed to insert student", details: err.message });
  }
});

// PUT update student
app.put("/api/students/:id", async (req, res) => {
  const { name, prn, email, year, branch, college } = req.body;
  const id = req.params.id;
  try {
    await client.execute(
      "UPDATE students SET name = ?, prn = ?, email = ?, year = ?, branch = ?, college = ? WHERE id = ?",
      [name, prn, email, parseInt(year), branch, college, Uuid.fromString(id)],
      { prepare: true }
    );
    console.log("✅ Updated student ID:", id);
    res.json({ message: "Updated" });
  } catch (err) {
    console.error("❌ PUT /api/students error:", err.message);
    res
      .status(500)
      .json({ error: "Failed to update student", details: err.message });
  }
});

// DELETE student
app.delete("/api/students/:id", async (req, res) => {
  try {
    const id = Uuid.fromString(req.params.id);
    await client.execute("DELETE FROM students WHERE id = ?", [id], {
      prepare: true,
    });
    console.log("🗑️ Deleted student ID:", id);
    res.json({ message: "Deleted" });
  } catch (err) {
    console.error("❌ DELETE /api/students error:", err.message);
    res
      .status(500)
      .json({ error: "Failed to delete student", details: err.message });
  }
});

// Start server
app.listen(5001, () => console.log("🚀 Server running on port 5001"));
