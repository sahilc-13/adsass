const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");

const app = express();
app.use(cors());
app.use(express.json());

mongoose
  .connect(
    "mongodb+srv://sahil:Sahil%409904@cluster0.fab2qdl.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0"
  )
  .then(() => console.log("MongoDB Connected"))
  .catch((err) => console.log(err));

const Student = mongoose.model("Student", {
  name: String,
  prn: String,
  email: String,
  year: String,
  branch: String,
  college: String,
});

// READ
app.get("/api/students", async (req, res) => {
  const students = await Student.find();
  res.json(students);
});

// CREATE
app.post("/api/students", async (req, res) => {
  const student = new Student(req.body);
  await student.save();
  res.json({ message: "Added" });
});

// UPDATE
app.put("/api/students/:id", async (req, res) => {
  try {
    const updatedStudent = await Student.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true }
    );
    res.json({ message: "Updated", student: updatedStudent });
  } catch (err) {
    res.status(400).json({ error: "Update failed", details: err });
  }
});

// DELETE
app.delete("/api/students/:id", async (req, res) => {
  await Student.findByIdAndDelete(req.params.id);
  res.json({ message: "Deleted" });
});

app.listen(5000, () => console.log("Mongo backend running on port 5000"));
